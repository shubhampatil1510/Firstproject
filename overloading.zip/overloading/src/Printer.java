
public class Printer {

	public void print(String string) {
		// TODO Auto-generated method stub
		
		System.out.println(string);
		
	}
	public void print(int d) {
		// TODO Auto-generated method stub
		
		System.out.println(d);
	}
		
	public void print(double d) {
		// TODO Auto-generated method stub
		
		System.out.println(d);
	}
   
}
