
public class Demo {
	
	public static void main(String[] args) {
		
		Printer p1 = new Printer();
		p1.print("Hello");
		
		
		int i=10;
		p1.print(i);
		
		double d1=90.8;
		p1.print(d1);
	}

}
